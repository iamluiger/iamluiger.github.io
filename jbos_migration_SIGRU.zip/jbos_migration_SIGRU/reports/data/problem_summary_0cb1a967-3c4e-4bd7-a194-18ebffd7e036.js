MIGRATION_ISSUES_DETAILS["0cb1a967-3c4e-4bd7-a194-18ebffd7e036"] = [
{description: "<p>Mailing is used in the application<\/p>", ruleID: "technology-usage-connect-01200", issueName: "Mail usage",
problemSummaryID: "0cb1a967-3c4e-4bd7-a194-18ebffd7e036", files: [
{l:"<a class='' href='RecibirMail_java.html?project=21667888'>com.Dinissan.comunicados.RecibirMail<\/a>", oc:"1"},
{l:"<a class='' href='EnviarMail_java.html?project=21667888'>com.Dinissan.comunicaciones.email.ejb.EnviarMail<\/a>", oc:"1"},
{l:"<a class='' href='TransmisorCorreo_java.html?project=21667888'>com.Dinissan.comunicaciones.email.envio.TransmisorCorreo<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("0cb1a967-3c4e-4bd7-a194-18ebffd7e036");