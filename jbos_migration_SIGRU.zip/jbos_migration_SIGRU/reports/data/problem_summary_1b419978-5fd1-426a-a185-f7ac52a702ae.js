MIGRATION_ISSUES_DETAILS["1b419978-5fd1-426a-a185-f7ac52a702ae"] = [
{description: "<p>The application embeds an Apache Commons Logging library.<\/p>", ruleID: "logging-usage-00020", issueName: "Embedded library - Apache Commons Logging",
problemSummaryID: "1b419978-5fd1-426a-a185-f7ac52a702ae", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/commons-logging-1.2.jar", oc:"1"},
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/commons-logging-1.1.1.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("1b419978-5fd1-426a-a185-f7ac52a702ae");