MIGRATION_ISSUES_DETAILS["290b525c-6672-4aab-b133-3433017e09ff"] = [
{description: "<p>The application embeds a Simple Logging Facade for Java (SLJ4J) library.<\/p>", ruleID: "logging-usage-00030", issueName: "Embedded library - SLF4J",
problemSummaryID: "290b525c-6672-4aab-b133-3433017e09ff", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/slf4j-api-1.7.26.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("290b525c-6672-4aab-b133-3433017e09ff");