MIGRATION_ISSUES_DETAILS["320dd6b9-e0ea-4682-8ad3-e434cd2ff6ab"] = [
{description: "<p>The application embeds a WSDL library.<\/p>", ruleID: "connect-01700", issueName: "Embedded library - WSDL",
problemSummaryID: "320dd6b9-e0ea-4682-8ad3-e434cd2ff6ab", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/wsdl4j-1.6.2.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("320dd6b9-e0ea-4682-8ad3-e434cd2ff6ab");