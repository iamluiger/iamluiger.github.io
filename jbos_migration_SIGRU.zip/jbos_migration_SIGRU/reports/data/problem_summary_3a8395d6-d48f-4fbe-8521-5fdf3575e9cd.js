MIGRATION_ISSUES_DETAILS["3a8395d6-d48f-4fbe-8521-5fdf3575e9cd"] = [
{description: "<p>This Class file could not be parsed<\/p>", ruleID: "BeforeDecompileClassesRuleProvider_1", issueName: "Unparseable Class File",
problemSummaryID: "3a8395d6-d48f-4fbe-8521-5fdf3575e9cd", files: [
{l:"module-info.class", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("3a8395d6-d48f-4fbe-8521-5fdf3575e9cd");