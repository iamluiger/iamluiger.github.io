MIGRATION_ISSUES_DETAILS["3cfe34c9-2bc3-4772-b85e-c6bec3e2f25e"] = [
{description: "<p>The application embeds an MySQL driver.<\/p>", ruleID: "database-01500", issueName: "Embedded MySQL Driver",
problemSummaryID: "3cfe34c9-2bc3-4772-b85e-c6bec3e2f25e", files: [
{l:"SIGRU.ear/AdminCU.war/WEB-INF/lib/mysql-connector-java-5.1.6.jar", oc:"1"},
], resourceLinks: [
{h:"https://access.redhat.com/articles/111663", t:"Red Hat JBoss Enterprise Application Platform (EAP) 6 Supported Configurations"},
{h:"https://access.redhat.com/articles/2026253", t:"Red Hat JBoss Enterprise Application Platform (EAP) 7 Supported Configurations"},
]},
];
onProblemSummaryLoaded("3cfe34c9-2bc3-4772-b85e-c6bec3e2f25e");