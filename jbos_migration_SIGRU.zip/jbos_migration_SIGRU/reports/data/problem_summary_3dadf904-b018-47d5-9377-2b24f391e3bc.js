MIGRATION_ISSUES_DETAILS["3dadf904-b018-47d5-9377-2b24f391e3bc"] = [
{description: "<p>The application embeds an Apache Log4J library.<\/p>", ruleID: "logging-usage-00010", issueName: "Embedded library - Apache Log4J",
problemSummaryID: "3dadf904-b018-47d5-9377-2b24f391e3bc", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/log4j-api-2.11.2.jar", oc:"1"},
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/log4j-core-2.11.2.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("3dadf904-b018-47d5-9377-2b24f391e3bc");