MIGRATION_ISSUES_DETAILS["3f5ca04f-8cdf-46ce-abcf-9f6e1adc0ff1"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "3f5ca04f-8cdf-46ce-abcf-9f6e1adc0ff1", files: [
{l:"<a class='' href='web_xml.html?project=21667888'>SIGRU.war/WEB-INF/web.xml<\/a>", oc:"1"},
{l:"<a class='' href='web_xml.14.html?project=21667888'>AdminCU.war/WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("3f5ca04f-8cdf-46ce-abcf-9f6e1adc0ff1");