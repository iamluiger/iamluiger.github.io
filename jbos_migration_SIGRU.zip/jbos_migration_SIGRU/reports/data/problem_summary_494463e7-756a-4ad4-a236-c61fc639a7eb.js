MIGRATION_ISSUES_DETAILS["494463e7-756a-4ad4-a236-c61fc639a7eb"] = [
{description: "<p>This XML file could not be parsed.<\/p>", ruleID: "DiscoverXmlFilesRuleProvider_5", issueName: "Unparsable XML File",
problemSummaryID: "494463e7-756a-4ad4-a236-c61fc639a7eb", files: [
{l:"<a class='' href='pedidosTab_xhtml.html?project=21667888'>SIGRU.war/prospectos/Gestion/Includes/pedidosTab.xhtml<\/a>", oc:"1"},
{l:"<a class='' href='retomaPeritajeTab_xhtml.html?project=21667888'>SIGRU.war/prospectos/Gestion/Includes/retomaPeritajeTab.xhtml<\/a>", oc:"1"},
{l:"<a class='' href='transaccionesTab_xhtml.html?project=21667888'>SIGRU.war/prospectos/Gestion/Includes/transaccionesTab.xhtml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("494463e7-756a-4ad4-a236-c61fc639a7eb");