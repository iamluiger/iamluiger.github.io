MIGRATION_ISSUES_DETAILS["4b1451ed-93fc-4cdd-8c83-14f8b1e92c67"] = [
{description: "<p>The application embeds a PrimeFaces library.<\/p>", ruleID: "mvc-02400", issueName: "Embedded library - PrimeFaces",
problemSummaryID: "4b1451ed-93fc-4cdd-8c83-14f8b1e92c67", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/primefaces-6.2.jar", oc:"1"},
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/primefaces-extensions-6.1.0.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("4b1451ed-93fc-4cdd-8c83-14f8b1e92c67");