MIGRATION_ISSUES_DETAILS["5c9d67ff-b340-40f7-b2cf-559b658b015b"] = [
{description: "<p>The application embeds a HTTP client.<\/p>", ruleID: "embedded-framework-05100", issueName: "Embedded framework - HTTP Client",
problemSummaryID: "5c9d67ff-b340-40f7-b2cf-559b658b015b", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/google-http-client-jackson2-1.29.1.jar", oc:"1"},
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/google-http-client-1.29.1.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("5c9d67ff-b340-40f7-b2cf-559b658b015b");