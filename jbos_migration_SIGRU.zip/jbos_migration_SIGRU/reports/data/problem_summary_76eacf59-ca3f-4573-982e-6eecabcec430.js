MIGRATION_ISSUES_DETAILS["76eacf59-ca3f-4573-982e-6eecabcec430"] = [
{description: "<p>The application embeds a JDBC library.<\/p>", ruleID: "embedded-framework-libraries-04000", issueName: "Embedded library - JDBC",
problemSummaryID: "76eacf59-ca3f-4573-982e-6eecabcec430", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/jdbc-4.50.1.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("76eacf59-ca3f-4573-982e-6eecabcec430");