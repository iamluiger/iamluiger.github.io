MIGRATION_ISSUES_DETAILS["7c50b603-5162-4cf2-a237-8c52060c8c92"] = [
{description: "<p>The application embeds a Bouncy Castle library.<\/p>", ruleID: "security-02000", issueName: "Embedded library - Bouncy Castle",
problemSummaryID: "7c50b603-5162-4cf2-a237-8c52060c8c92", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/bcmail-jdk14-1.38.jar", oc:"1"},
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/bcpkix-jdk14-1.61.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("7c50b603-5162-4cf2-a237-8c52060c8c92");