MIGRATION_ISSUES_DETAILS["8a204603-baad-4028-933a-6dc871d3a229"] = [
{description: "<p>The application embeds the Apache Axis framework.<\/p>", ruleID: "embedded-framework-01000", issueName: "Embedded framework - Apache Axis",
problemSummaryID: "8a204603-baad-4028-933a-6dc871d3a229", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/axis-1.4.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("8a204603-baad-4028-933a-6dc871d3a229");