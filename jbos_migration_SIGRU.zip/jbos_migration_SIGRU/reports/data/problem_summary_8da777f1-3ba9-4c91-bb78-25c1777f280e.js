MIGRATION_ISSUES_DETAILS["8da777f1-3ba9-4c91-bb78-25c1777f280e"] = [
{description: "<p>The application embeds an OAUTH library.<\/p>", ruleID: "security-03100", issueName: "Embedded library - OAUTH",
problemSummaryID: "8da777f1-3ba9-4c91-bb78-25c1777f280e", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/google-oauth-client-1.29.0.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("8da777f1-3ba9-4c91-bb78-25c1777f280e");