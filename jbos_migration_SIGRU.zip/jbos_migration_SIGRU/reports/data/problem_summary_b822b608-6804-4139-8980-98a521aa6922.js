MIGRATION_ISSUES_DETAILS["b822b608-6804-4139-8980-98a521aa6922"] = [
{description: "<p>The application embeds a Javax Inject library.<\/p>", ruleID: "embedded-framework-05300", issueName: "Embedded framework - Javax Inject",
problemSummaryID: "b822b608-6804-4139-8980-98a521aa6922", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/javax.inject-1.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("b822b608-6804-4139-8980-98a521aa6922");