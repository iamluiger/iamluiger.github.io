MIGRATION_ISSUES_DETAILS["bc602659-f552-407f-b72e-3da8bc9cb7ff"] = [
{description: "<p>The application embeds the Spring framework.<\/p>", ruleID: "embedded-framework-05200", issueName: "Embedded framework - Spring",
problemSummaryID: "bc602659-f552-407f-b72e-3da8bc9cb7ff", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/spring-expression-3.0.6.RELEASE.jar", oc:"1"},
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/spring-context-3.0.6.RELEASE.jar", oc:"1"},
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/spring-asm-3.0.6.RELEASE.jar", oc:"1"},
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/spring-beans-3.0.6.RELEASE.jar", oc:"1"},
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/spring-aop-3.0.6.RELEASE.jar", oc:"1"},
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/spring-core-3.0.6.RELEASE.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("bc602659-f552-407f-b72e-3da8bc9cb7ff");