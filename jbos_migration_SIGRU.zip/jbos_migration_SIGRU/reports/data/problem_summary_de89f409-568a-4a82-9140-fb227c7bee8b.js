MIGRATION_ISSUES_DETAILS["de89f409-568a-4a82-9140-fb227c7bee8b"] = [
{description: "<p>The application embeds an OWASP ESAPI library.<\/p>", ruleID: "security-02600", issueName: "Embedded library - OWASP ESAPI",
problemSummaryID: "de89f409-568a-4a82-9140-fb227c7bee8b", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/curvesapi-1.04.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("de89f409-568a-4a82-9140-fb227c7bee8b");