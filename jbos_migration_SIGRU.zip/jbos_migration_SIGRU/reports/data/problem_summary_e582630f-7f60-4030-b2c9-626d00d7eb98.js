MIGRATION_ISSUES_DETAILS["e582630f-7f60-4030-b2c9-626d00d7eb98"] = [
{description: "<p>The application embeds the AOP Alliance library.<\/p>", ruleID: "embedded-framework-04700", issueName: "Embedded framework - AOP Alliance",
problemSummaryID: "e582630f-7f60-4030-b2c9-626d00d7eb98", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/aopalliance-1.0.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("e582630f-7f60-4030-b2c9-626d00d7eb98");