MIGRATION_ISSUES_DETAILS["f6c50ebf-5ea9-49e2-b75c-0938e87c6afc"] = [
{description: "<p>The application embeds a JFreeChart library.<\/p>", ruleID: "mvc-02700", issueName: "Embedded library - JFreeChart",
problemSummaryID: "f6c50ebf-5ea9-49e2-b75c-0938e87c6afc", files: [
{l:"SIGRU.ear/SIGRU.war/WEB-INF/lib/jfreechart-1.0.19.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("f6c50ebf-5ea9-49e2-b75c-0938e87c6afc");